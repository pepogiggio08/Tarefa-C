#include <stdio.h>
int main()
{
	float ValPed = 0, InvPed = 0, QtdSup = 0, afirm, TotalVenda = 0, TotalDesc = 0, TotalEfetivo = 0;
	do{
		float cod, quant, valunit, desc, subTot, percent, valF;
		
		do{
		printf("Insira o valor do codigo do produto (1, 2, 3 ou 4 apenas) ");
		scanf("%f", &cod);
		
		switch(cod == 1)
		case(1 == 1): percent = 0, ValPed = ValPed + 1;
		switch(cod == 2)
		case(2 == 2): percent = 8, ValPed = ValPed + 1;
		switch(cod == 3)
		case(3 == 3): percent = 12, ValPed = ValPed + 1;
		switch(cod == 4)
		case(4 == 4): percent = 15, ValPed = ValPed + 1;
		
		switch(cod != 1 && cod != 2 && cod != 3 && cod != 4)
		case (5 == 5):
		printf("\nPedido invalido!\n"), InvPed = InvPed + 1;
		} while(cod != 1 && cod != 2 && cod != 3 && cod != 4);
		
		printf("Insira a quantia de produtos comprada: ");
		scanf("%f", &quant);
		
		printf("Insira o valor unitario do produto: ");
		scanf("%f", &valunit);
		
		subTot = quant * valunit;
		TotalVenda = TotalVenda + subTot;
		
		desc = subTot * (percent/100);
		TotalDesc = TotalDesc + desc;
		
		valF = subTot - desc;
		if(valF > 1000)
		{
			QtdSup = QtdSup + 1;
		}
		TotalEfetivo = TotalEfetivo + valF;
		
		do{
		printf("\nDeseja continuar registrando produtos? (1 - sim, 0 - nao) ");
		scanf("%f", &afirm);
		if(afirm != 0 && afirm != 1)
		{
			printf("\nEntrada inv�lida!\nDigite 0 ou 1 para prosseguir!\n");
		}
		}while (afirm != 0 && afirm != 1);
	
	}while(afirm == 1);
	
	printf("\nA quantidade de pedidos validos processados e: %2.f", ValPed);
	printf("\nA quantidade de pedidos invalidos processados e: %2.f", InvPed);
	printf("\n\nO valor total das vendas antes dos descontos e de: %2.f", TotalVenda);
	printf("\nO valor total concedido em descontos e: %2.f", TotalDesc);
	printf("\nO valor total recebido efetivamente pela distribuidora e: %2.f", TotalEfetivo);
	printf("\n\n O n de itens cujo valor final e superior a 1000 e: %2.f", QtdSup);
}
