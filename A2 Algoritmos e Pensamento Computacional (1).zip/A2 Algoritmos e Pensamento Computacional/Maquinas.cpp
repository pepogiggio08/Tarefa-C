#include <stdio.h>
int main()
{
	int criticas, i, COMPi = 0;
	float COMPtaxadef, ARBpecas, ARBdefeito = 0;
	COMPtaxadef = 0;
	criticas = 0;
	
	for(i = 0; i < 10; i++)
	{
		float taxadef, pecas, defeito;
		
		printf("insira a quantidade de pecas produzidas: ");
		scanf("%f", &pecas);
		ARBpecas = ARBpecas + pecas;
		
		printf("insira a quantidade de pecas com defeito: ");
		scanf("%f", &defeito);
		ARBdefeito = ARBdefeito + defeito;
		
		taxadef = defeito/pecas * 100;
		if(taxadef > COMPtaxadef)
		{
			COMPtaxadef = taxadef;
			COMPi = i + 1 ;
		}
		
		if (taxadef <= 2)
		{
			printf("\nA situacao da maquina e excelente!\n");
		}
		if (taxadef > 2 && taxadef <= 5)
		{
			printf("\nA situacao da maquina e aceitavel\n");
		}
		if (taxadef >= 5)
		{
			printf("\nA situacao da maquina e critica\n");
			criticas = criticas + 1;
		}
		
	}
	float a;
	a = ARBdefeito/ARBpecas * 100;
	
	printf("\nA quantidade total de pecas produzidas e: %.2f", ARBpecas);
	printf("\nA quantidade total de pecas com defeito e: %.2f", ARBdefeito);
	printf("\nA quantidade de maquinas consideradas criticas e: %d", criticas);
	printf("\nO n da maquina que deu a maior taxa de defeito e: %d", COMPi);
	printf("\nA taxa geral de defeitos considerando todas as maquinas e: %f", a);
	
	return 0;
}
