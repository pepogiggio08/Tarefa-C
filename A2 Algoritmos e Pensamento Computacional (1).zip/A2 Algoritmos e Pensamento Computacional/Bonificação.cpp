#include <stdio.h>
int main()
{
	float sal, a, b;
	int h;
	printf("Insira o valor do salario atua: ");
	scanf("%f", &sal);
	printf("Insira o valor das horas extras trabalhadas: ");
	scanf("%d", &h);
	
	if(sal <= 2500 && h >= 20)
	{
		b = (sal * 0.15);
		a = sal + b;
	}
	if(2500 < sal && sal <= 4000 && h >= 10)
	{
		b = (sal * 0.1);
		a = sal + b;
	}
	if(sal > 4000 && h >= 10)
	{
		b = (sal * 0.05);
		a = sal + b;
	}
	printf("\nO valor do salario orginial e: %f", sal);
	printf("\nO valor da bonificacao e: %f", b);
	printf("\nO valor do salario final e: %f: ", a);
	
	return 0;
}
